import { createReducer, on } from '@ngrx/store';
import * as AuthActions from './auth.actions';

export interface AuthState {
  loading: boolean;     // Spinner
  message: string | null; // Message vert "Email envoyé"
  error: string | null;   // Message rouge "Erreur..."
  token: string | null;      // <--- Nouveau
  user: any | null;          // <--- Nouveau
  isAuthenticated: boolean;  // <--- Nouveau
}

export const initialState: AuthState = {
  loading: false,
  message: null,
  token: localStorage.getItem('token'), // On tente de le récupérer s'il existe déjà
  isAuthenticated: !!localStorage.getItem('token'),
  user: null,
  error: null
};

export const authReducer = createReducer(
  initialState,
  
  // Quand on lance le login -> Loading on, reset messages
on(AuthActions.verifyToken, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(AuthActions.verifyTokenSuccess, (state, { token, user }) => ({
    ...state,
    loading: false,
    token,
    user,
    isAuthenticated: true,
    error: null
  })),
  on(AuthActions.verifyTokenFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
    isAuthenticated: false
  }))
);