import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';

// Material Modules
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';

import * as TaskActions from '../../../../store/tasks/tasks.actions';
import { Task, TaskStatus } from '../../../../shared/models/task.model';
import { TaskFormComponent } from '../../components/task-form.component';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatMenuModule,
    MatTooltipModule,
    MatProgressSpinnerModule
    ,MatDialogModule,
    TaskFormComponent
  ],
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit {
  private store = inject(Store);

  // Colonnes du tableau
  displayedColumns: string[] = ['status', 'title', 'priority', 'assigned_to', 'due_date', 'actions'];

  // Signaux NgRx
  tasks = this.store.selectSignal((state: any) => state.tasks.tasks);
  loading = this.store.selectSignal((state: any) => state.tasks.loading);
  error = this.store.selectSignal((state: any) => state.tasks.error);

  private dialog = inject(MatDialog);

  ngOnInit() {
    this.store.dispatch(TaskActions.loadTasks({ page: 1 }));
  }

  // --- ACTIONS ---

  onAdd() {
    const ref = this.dialog.open(TaskFormComponent, {
      width: '640px',
      data: null
    });

    ref.afterClosed().subscribe(() => {
      // Refresh list after dialog closed (user saved/edited)
      this.store.dispatch(TaskActions.loadTasks({ page: 1 }));
    });
  }

  onEdit(task: Task) {
    const ref = this.dialog.open(TaskFormComponent, {
      width: '640px',
      data: { task }
    });

    ref.afterClosed().subscribe(() => {
      this.store.dispatch(TaskActions.loadTasks({ page: 1 }));
    });
  }

  onDelete(task: Task) {
    if (confirm(`Voulez-vous vraiment supprimer "${task.title}" ?`)) {
      // TODO: Créer l'action deleteTask dans le store
      // this.store.dispatch(TaskActions.deleteTask({ id: task.id }));
      console.log('Delete', task.id);
    }
  }

  onStatusChange(task: Task, newStatus: TaskStatus) {
    // Optimistic UI update à faire via le store
    console.log('Changer status', task.id, newStatus);
  }

  // --- HELPERS UI ---

  getStatusLabel(status: string): string {
    switch (status) {
      case 'todo': return 'À faire';
      case 'in_progress': return 'En cours';
      case 'done': return 'Terminé';
      default: return status;
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'todo': return 'bg-slate-100 text-slate-600 border-slate-200';
      case 'in_progress': return 'bg-blue-50 text-blue-600 border-blue-200';
      case 'done': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
      default: return '';
    }
  }

  getPriorityClass(priority: string): string {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-amber-600 bg-amber-50';
      case 'low': return 'text-slate-500 bg-slate-50';
      default: return '';
    }
  }

  getPriorityIcon(priority: string): string {
    switch (priority) {
      case 'high': return 'keyboard_double_arrow_up';
      case 'medium': return 'keyboard_arrow_up';
      case 'low': return 'keyboard_arrow_down';
      default: return 'remove';
    }
  }
}