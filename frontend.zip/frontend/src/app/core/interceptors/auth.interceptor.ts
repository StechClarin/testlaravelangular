import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // 1. Récupérer le token stocké (mis dans le localStorage par AuthEffects)
  const token = localStorage.getItem('token');

  // 2. Si un token existe, on clone la requête pour ajouter le header Authorization
  if (token) {
    const clonedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(clonedRequest);
  }

  // 3. Sinon, on laisse passer la requête telle quelle (ex: Login)
  return next(req);
};