import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Task, TaskResponse } from '../../shared/models/task.model';

@Injectable({ providedIn: 'root' })
export class TaskService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/tasks`;

  // 1. Récupérer la liste (Existant)
  getTasks(page = 1, filters: any = {}): Observable<TaskResponse> {
    let params = new HttpParams().set('page', page.toString());

    if (filters.status) params = params.set('status', filters.status);
    if (filters.priority) params = params.set('priority', filters.priority);
    if (filters.search) params = params.set('search', filters.search);

    return this.http.get<TaskResponse>(this.apiUrl, { params });
  }

  // 2. Créer une tâche (NOUVEAU)
  createTask(task: Partial<Task>): Observable<Task> {
    return this.http.post<Task>(this.apiUrl, task);
  }

  // 3. Modifier une tâche (NOUVEAU)
  updateTask(id: number, task: Partial<Task>): Observable<Task> {
    return this.http.put<Task>(`${this.apiUrl}/${id}`, task);
  }

  // 4. Supprimer une tâche (NOUVEAU)
  deleteTask(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  // 5. Récupérer les utilisateurs pour le Select "Assigné à" (NOUVEAU)
  getUsers(): Observable<any[]> {
    // On appelle l'endpoint /api/users que nous avons créé dans le UserController Laravel
    // On récupère juste la liste (souvent paginée, ici on prend "data" si c'est paginé, sinon le tableau direct)
    return this.http.get<any>(`${environment.apiUrl}/users`).pipe(
      // Petite astuce : si Laravel renvoie une pagination, on prend .data, sinon la réponse
      // map(response => response.data || response) 
      // (On laisse simple pour l'instant, adapte selon ton UserController::index)
    );
  }
}