// Adaptation selon ta migration Laravel
export type TaskStatus = 'todo' | 'in_progress' | 'done';
export type TaskPriority = 'low' | 'medium' | 'high';

export interface Task {
  id: number;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: TaskPriority;
  due_date: string;
  // Relations
  assigned_to?: number;
  assigned_to_user?: { id: number, name: string, email: string }; // Pour l'affichage
  created_by: number;
  created_at?: string;
  updated_at?: string;
}

export interface TaskResponse {
  data: Task[];
  meta: any;
}