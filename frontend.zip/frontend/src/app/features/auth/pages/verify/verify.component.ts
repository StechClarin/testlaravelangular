import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import * as AuthActions from '../../../../store/auth/auth.actions';

@Component({
  selector: 'app-verify',
  standalone: true,
  imports: [
    CommonModule, 
    MatProgressSpinnerModule, 
    MatCardModule, 
    MatButtonModule,
    MatIconModule,
    RouterLink
  ],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <mat-card class="w-full max-w-md p-8 text-center shadow-xl rounded-2xl">
        
        <div *ngIf="loading()" class="flex flex-col items-center gap-4">
          <mat-spinner diameter="50" color="primary"></mat-spinner>
          <h2 class="text-xl font-semibold text-slate-700">Vérification de votre lien...</h2>
          <p class="text-slate-500">Veuillez patienter un instant.</p>
        </div>

        <div *ngIf="error()" class="flex flex-col items-center gap-4 animate-fade-in">
          <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-2">
            <mat-icon class="text-red-500 scale-150">broken_image</mat-icon>
          </div>
          <h2 class="text-xl font-bold text-red-600">Lien invalide ou expiré</h2>
          <p class="text-slate-600 mb-4">{{ error() }}</p>
          
          <a mat-flat-button color="primary" routerLink="/login">
            Retour à la connexion
          </a>
        </div>

      </mat-card>
    </div>
  `
})
export class VerifyComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private store = inject(Store);

  loading = this.store.selectSignal((state: any) => state.auth.loading);
  error = this.store.selectSignal((state: any) => state.auth.error);

  ngOnInit() {
    // Récupère le token depuis l'URL : /auth/verify/MON_TOKEN_ICI
    const token = this.route.snapshot.paramMap.get('token');
    
    if (token) {
      this.store.dispatch(AuthActions.verifyToken({ token }));
    } else {
      this.store.dispatch(AuthActions.verifyTokenFailure({ error: 'Token manquant' }));
    }
  }
}