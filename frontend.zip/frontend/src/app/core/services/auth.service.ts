import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/auth`; // http://localhost:8000/api/auth

  // 1. Demander le lien magique
  requestMagicLink(email: string): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/request-magic-link`, { email });
  }

  // 2. Vérifier le token (on l'utilisera juste après)
  verifyMagicLink(token: string): Observable<{ token: string }> {
    return this.http.get<{ token: string }>(`${this.apiUrl}/verify-magic-link/${token}`);
  }
}