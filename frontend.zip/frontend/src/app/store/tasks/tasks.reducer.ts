import { createReducer, on } from '@ngrx/store';
import * as TaskActions from './tasks.actions';
import { Task } from '../../shared/models/task.model';

export interface TaskState {
  tasks: Task[];
  meta: any; // Pagination
  loading: boolean;
  error: string | null;
}

export const initialState: TaskState = {
  tasks: [],
  meta: null,
  loading: false,
  error: null
};

export const taskReducer = createReducer(
  initialState,
  on(TaskActions.loadTasks, (state) => ({
    ...state,
    loading: true,
    error: null
  })),
  on(TaskActions.loadTasksSuccess, (state, { tasks, meta }) => ({
    ...state,
    loading: false,
    tasks,
    meta
  })),
  on(TaskActions.loadTasksFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error
  }))
);