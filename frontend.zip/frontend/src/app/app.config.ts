import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

// --- IMPORTS NGRX ---
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';

// --- IMPORTS AUTH ---
import { authReducer } from './store/auth/auth.reducer';
import { AuthEffects } from './store/auth/auth.effects';
import { authInterceptor } from './core/interceptors/auth.interceptor';

// --- IMPORTS TASKS (NOUVEAU) ---
import { taskReducer } from './store/tasks/tasks.reducer';
import { TaskEffects } from './store/tasks/tasks.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    
    // Configuration HTTP avec l'interceptor pour le Token JWT
    provideHttpClient(
      withInterceptors([authInterceptor])
    ),

    provideAnimationsAsync(),

    // --- CONFIGURATION DU STORE ---
    provideStore({ 
      auth: authReducer,
      tasks: taskReducer // <--- On ajoute le reducer des tâches ici
    }),
    
    // --- CONFIGURATION DES EFFECTS ---
    provideEffects([
      AuthEffects,
      TaskEffects        // <--- On ajoute les effets des tâches ici
    ])
  ]
};