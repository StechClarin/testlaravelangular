import { createAction, props } from '@ngrx/store';

// Actions pour la page de Login
export const login = createAction('[Auth] Login', props<{ email: string }>());
export const loginSuccess = createAction('[Auth] Login Success', props<{ message: string }>());
export const loginFailure = createAction('[Auth] Login Failure', props<{ error: string }>());
export const verifyToken = createAction('[Auth] Verify Token', props<{ token: string }>());
export const verifyTokenSuccess = createAction('[Auth] Verify Token Success', props<{ token: string, user: any }>()); // On recevra le JWT et l'user
export const verifyTokenFailure = createAction('[Auth] Verify Token Failure', props<{ error: string }>());