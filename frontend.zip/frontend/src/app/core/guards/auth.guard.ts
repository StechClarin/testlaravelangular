import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('token');

  if (token) {
    // Si le token est là, on laisse passer
    return true;
  } else {
    // Sinon, retour à la case départ
    router.navigate(['/login']);
    return false;
  }
};