import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/pages/login/login.component';
import { VerifyComponent } from './features/auth/pages/verify/verify.component';
// Cet import fonctionne maintenant que le composant est créé :
import { TaskListComponent } from './features/tasks/pages/task-list/task-list.component';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  // Redirection par défaut vers le login
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // --- ROUTES PUBLIQUES ---
  { path: 'login', component: LoginComponent },
  { path: 'auth/verify/:token', component: VerifyComponent },

  // --- ROUTES PROTÉGÉES ---
  { 
    path: 'tasks', 
    component: TaskListComponent,
    canActivate: [authGuard] // Le garde de sécurité vérifie le token
  }
];