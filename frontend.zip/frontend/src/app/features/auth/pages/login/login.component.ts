import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';

// Material UI Imports
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';

// Actions du Store
import * as AuthActions from '../../../../store/auth/auth.actions';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatFormFieldModule,
    MatIconModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private store = inject(Store);

  // Formulaire Réactif
  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]]
  });

  // --- LE COEUR DU SUJET : SIGNALS ---
  // Au lieu d'observables async pipe, on utilise selectSignal
  loading = this.store.selectSignal((state: any) => state.auth.loading);
  error = this.store.selectSignal((state: any) => state.auth.error);
  message = this.store.selectSignal((state: any) => state.auth.message);

  onSubmit() {
    if (this.loginForm.valid) {
      const email = this.loginForm.value.email!;
      // On déclenche l'action qui sera interceptée par l'Effect
      this.store.dispatch(AuthActions.login({ email }));
    }
  }
}