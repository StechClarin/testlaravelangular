import { createAction, props } from '@ngrx/store';
import { Task } from '../../shared/models/task.model';

// Load tasks (pagination). `filters` is optional and accepted by effects.
export const loadTasks = createAction(
	'[Tasks] Load Tasks',
	props<{ page: number; filters?: any }>()
);

// Load success returns tasks + optional meta (pagination metadata)
export const loadTasksSuccess = createAction(
	'[Tasks] Load Tasks Success',
	props<{ tasks: Task[]; meta?: any }>()
);

export const loadTasksFailure = createAction(
	'[Tasks] Load Tasks Failure',
	props<{ error: any }>()
);

// Optional: delete task action
export const deleteTask = createAction(
	'[Tasks] Delete Task',
	props<{ id: number }>()
);

export const deleteTaskSuccess = createAction(
	'[Tasks] Delete Task Success',
	props<{ id: number }>()
);

export const deleteTaskFailure = createAction(
	'[Tasks] Delete Task Failure',
	props<{ error: any }>()
);

// Update task (partial update)
export const updateTask = createAction(
	'[Tasks] Update Task',
	props<{ task: Partial<Task> }>()
);

export const updateTaskSuccess = createAction(
	'[Tasks] Update Task Success',
	props<{ task: Task }>()
);

export const updateTaskFailure = createAction(
	'[Tasks] Update Task Failure',
	props<{ error: any }>()
);

// Create task
export const createTask = createAction(
	'[Tasks] Create Task',
	props<{ task: Partial<Task> }>()
);

export const createTaskSuccess = createAction(
	'[Tasks] Create Task Success',
	props<{ task: Task }>()
);

export const createTaskFailure = createAction(
	'[Tasks] Create Task Failure',
	props<{ error: any }>()
);
