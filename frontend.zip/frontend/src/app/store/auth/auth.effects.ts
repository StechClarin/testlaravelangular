import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { HttpClient } from '@angular/common/http';
import { map, switchMap, catchError, tap } from 'rxjs/operators';
import { of } from 'rxjs';
import * as AuthActions from './auth.actions';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Injectable()
export class AuthEffects {
  private actions$ = inject(Actions);
  private http = inject(HttpClient);
  private router = inject(Router);

  // Vérifier un token (flow Magic Link)
  verifyToken$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.verifyToken),
      switchMap(({ token }) =>
        this.http.get<any>(`${environment.apiUrl}/auth/verify-magic-link/${token}`).pipe(
          map((res) => AuthActions.verifyTokenSuccess({ token: res.token, user: res.user })),
          catchError((error) => of(AuthActions.verifyTokenFailure({ error: error.error?.message || 'Verification failed' })))
        )
      )
    )
  );

  // On success: persist token and redirect to task list
  verifyTokenSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.verifyTokenSuccess),
        tap(({ token }) => {
          try {
            localStorage.setItem('token', token);
          } catch (e) {
            // ignore storage errors
          }
          // navigate to tasks page
          this.router.navigate(['/tasks']);
        })
      ),
    { dispatch: false }
  );

  // Demander l'envoi du Magic Link
  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.login),
      switchMap(({ email }) =>
        this.http.post<any>(`${environment.apiUrl}/auth/request-magic-link`, { email }).pipe(
          map((res) => AuthActions.loginSuccess({ message: res.message || 'Email envoyé' })),
          catchError((error) => of(AuthActions.loginFailure({ error: error.error?.message || 'Login failed' })))
        )
      )
    )
  );
}