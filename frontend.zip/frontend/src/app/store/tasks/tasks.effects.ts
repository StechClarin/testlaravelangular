import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { TaskService } from '../../core/services/task.service';
import * as TaskActions from './tasks.actions';
import { catchError, map, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable()
export class TaskEffects {
  private actions$ = inject(Actions);
  private taskService = inject(TaskService);

  loadTasks$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskActions.loadTasks),
      switchMap(({ page, filters }) =>
        this.taskService.getTasks(page, filters).pipe(
          map((response) => TaskActions.loadTasksSuccess({ 
            tasks: response.data, // Laravel renvoie { data: [...], meta: ... } via API Resource
            meta: response.meta || {} 
          })),
          catchError((error) => of(TaskActions.loadTasksFailure({ 
            error: error.error?.message || 'Erreur de chargement' 
          })))
        )
      )
    )
  );

  // Create task effect
  createTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskActions.createTask),
      switchMap(({ task }) =>
        this.taskService.createTask(task).pipe(
          map((created) => TaskActions.createTaskSuccess({ task: created })),
          catchError((error) => of(TaskActions.createTaskFailure({ error: error.error?.message || 'Create failed' })))
        )
      )
    )
  );

  // Update task effect
  updateTask$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskActions.updateTask),
      switchMap(({ task }) => {
        const id = (task as any).id as number;
        return this.taskService.updateTask(id, task).pipe(
          map((updated) => TaskActions.updateTaskSuccess({ task: updated })),
          catchError((error) => of(TaskActions.updateTaskFailure({ error: error.error?.message || 'Update failed' })))
        );
      })
    )
  );
}