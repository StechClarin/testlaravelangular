import { Component, inject, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

// --- IMPORTS MATERIAL NÉCESSAIRES ---
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';      // Pour les Dropdowns
import { MatDatepickerModule } from '@angular/material/datepicker'; // Pour la date
import { MatNativeDateModule } from '@angular/material/core';    // Pour la date
import { MatIconModule } from '@angular/material/icon';

import * as TaskActions from '../../../store/tasks/tasks.actions';
import { Task } from '../../../shared/models/task.model';
import { TaskService } from '../../../core/services/task.service';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    MatDialogModule,
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule,
    MatSelectModule,      // <--- Ajout
    MatDatepickerModule,  // <--- Ajout
    MatNativeDateModule,  // <--- Ajout
    MatIconModule
  ],
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.scss']
})
export class TaskFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  public dialogRef = inject(MatDialogRef<TaskFormComponent>);
  private store = inject(Store);
  private taskService = inject(TaskService);

  // Observable pour remplir la liste déroulante "Assigné à"
  users$: Observable<any[]> = this.taskService.getUsers();

  constructor(@Inject(MAT_DIALOG_DATA) public data: { task?: Task } = {}) {}

  form = this.fb.group({
    title: ['', Validators.required],
    description: [''],
    // Valeurs par défaut selon ta migration
    status: ['todo', Validators.required], 
    priority: ['medium', Validators.required],
    // La date est obligatoire dans ta migration
    due_date: [null as Date | null, Validators.required], 
    assigned_to: [null as number | null]
  });

  ngOnInit() {
    // Si mode édition, on remplit le formulaire
    if (this.data && this.data.task) {
      const task = this.data.task;
      const patch: any = {
        title: task.title,
        description: task.description,
        status: task.status,
        priority: task.priority,
        assigned_to: task.assigned_to ?? null
      };

      // Convertir due_date (string) en Date pour le form control
      if (task.due_date) {
        patch.due_date = new Date(task.due_date);
      } else {
        patch.due_date = null;
      }

      this.form.patchValue(patch);
    }
  }

  submit() {
    if (this.form.invalid) return;

    const formValue = this.form.value;

    // --- CONVERSION DATE ---
    // Angular Material renvoie un objet Date, Laravel veut 'YYYY-MM-DD'
    let formattedDate = formValue.due_date;
    if (formValue.due_date instanceof Date) {
      formattedDate = formValue.due_date.toISOString().split('T')[0] as any;
    }

    // On prépare l'objet propre
    const payload: Partial<Task> = {
      ...formValue,
      due_date: formattedDate
    } as Partial<Task>;

    // --- UTILISATION DU STORE (Recommandé) ---
    // On dispatch l'action, l'Effect s'occupe de l'API et du refresh de la liste.
    
    if (this.data && this.data.task && this.data.task.id) {
      // UPDATE
      this.store.dispatch(TaskActions.updateTask({ 
        task: { ...payload, id: this.data.task.id } 
      }));
    } else {
      // CREATE
      this.store.dispatch(TaskActions.createTask({ task: payload }));
    }

    // On ferme la modale immédiatement
    this.dialogRef.close(true);
  }
}